# cricket-ball-detector > 2025-06-16 2:58am
https://universe.roboflow.com/my-projects-ckiu2/cricket-ball-detector

Provided by a Roboflow user
License: MIT

