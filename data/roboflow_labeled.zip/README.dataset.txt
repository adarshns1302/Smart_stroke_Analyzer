# cricket-ball-detector > 2025-06-22 12:58am
https://universe.roboflow.com/my-projects-ckiu2/cricket-ball-detector

Provided by a Roboflow user
License: MIT

